package com.example.myweightjourney_savannahpierce;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsNotificationsActivity extends AppCompatActivity {

    private EditText editPhoneNumber;
    private EditText editGoalWeight;
    private TextView textPermissionStatus;

    private Button buttonAllowSms;
    private Button buttonDeclineSms;
    private Button buttonBackToTracker;

    private String username;

    private SharedPreferences preferences;

    // Handles the result of the Android SMS permission request.
    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        // Connect Java variables to the views in the XML layout.
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        editGoalWeight = findViewById(R.id.editGoalWeight);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        buttonDeclineSms = findViewById(R.id.buttonDeclineSms);
        buttonBackToTracker = findViewById(R.id.buttonBackToTracker);

        // Receive the username from WeightTrackerActivity.
        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            Toast.makeText(
                    this,
                    "Unable to identify the logged-in user.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        /*
         * Each user's notification settings are stored separately.
         * SharedPreferences keeps this information after the app closes.
         */
        preferences = getSharedPreferences(
                "sms_settings_" + username,
                MODE_PRIVATE
        );

        // Load any settings that the user previously saved.
        loadSavedSettings();

        /*
         * Register the Android runtime permission request.
         * The app will continue functioning whether the user accepts
         * or denies SMS permission.
         */
        smsPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.RequestPermission(),
                        isGranted -> {

                            if (isGranted) {

                                saveNotificationSettings(true);

                                textPermissionStatus.setText(
                                        "SMS notifications are enabled."
                                );

                                Toast.makeText(
                                        this,
                                        "SMS permission granted.",
                                        Toast.LENGTH_SHORT
                                ).show();

                            } else {

                                saveNotificationSettings(false);

                                textPermissionStatus.setText(
                                        "SMS permission was denied. " +
                                                "The rest of the app will continue to work normally."
                                );

                                Toast.makeText(
                                        this,
                                        "SMS permission denied.",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                );

        // Ask Android for permission when the user selects Allow SMS.
        buttonAllowSms.setOnClickListener(view -> requestSmsPermission());

        /*
         * The user can choose not to use SMS notifications.
         * This does not interfere with any other app features.
         */
        buttonDeclineSms.setOnClickListener(view -> {

            saveNotificationSettings(false);

            textPermissionStatus.setText(
                    "SMS notifications are disabled. " +
                            "Weight tracking will continue normally."
            );

            Toast.makeText(
                    this,
                    "SMS notifications disabled.",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Return to the Weight Tracker screen.
        buttonBackToTracker.setOnClickListener(view -> {

            saveCurrentValues();

            Intent intent = new Intent(
                    SmsNotificationsActivity.this,
                    WeightTrackerActivity.class
            );

            intent.putExtra("username", username);

            startActivity(intent);
            finish();
        });

        // Display the current permission state when the screen opens.
        updatePermissionStatus();
    }

    /**
     * Requests SEND_SMS permission from Android.
     */
    private void requestSmsPermission() {

        if (!validateSettings()) {
            return;
        }

        // Save the phone number and goal before requesting permission.
        saveCurrentValues();

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            // Permission was already granted previously.
            saveNotificationSettings(true);

            textPermissionStatus.setText(
                    "SMS notifications are enabled."
            );

            Toast.makeText(
                    this,
                    "SMS permission is already enabled.",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            // Display Android's runtime permission dialog.
            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    /**
     * Makes sure the user supplied a phone number and valid goal weight.
     */
    private boolean validateSettings() {

        String phoneNumber =
                editPhoneNumber.getText().toString().trim();

        String goalWeightText =
                editGoalWeight.getText().toString().trim();

        if (phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter a phone number.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        if (goalWeightText.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter a goal weight.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        try {

            double goalWeight =
                    Double.parseDouble(goalWeightText);

            if (goalWeight <= 0) {

                Toast.makeText(
                        this,
                        "Please enter a valid goal weight.",
                        Toast.LENGTH_SHORT
                ).show();

                return false;
            }

        } catch (NumberFormatException exception) {

            Toast.makeText(
                    this,
                    "Please enter a valid goal weight.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        return true;
    }

    /**
     * Saves the user's phone number and goal weight.
     */
    private void saveCurrentValues() {

        String phoneNumber =
                editPhoneNumber.getText().toString().trim();

        String goalWeight =
                editGoalWeight.getText().toString().trim();

        SharedPreferences.Editor editor =
                preferences.edit();

        editor.putString(
                "phone_number",
                phoneNumber
        );

        editor.putString(
                "goal_weight",
                goalWeight
        );

        editor.apply();
    }

    /**
     * Saves whether the user wants SMS goal notifications enabled.
     */
    private void saveNotificationSettings(boolean enabled) {

        saveCurrentValues();

        preferences.edit()
                .putBoolean(
                        "notifications_enabled",
                        enabled
                )
                .apply();
    }

    /**
     * Restores previously saved phone number and goal weight values.
     */
    private void loadSavedSettings() {

        String savedPhone =
                preferences.getString(
                        "phone_number",
                        ""
                );

        String savedGoal =
                preferences.getString(
                        "goal_weight",
                        ""
                );

        editPhoneNumber.setText(savedPhone);
        editGoalWeight.setText(savedGoal);
    }

    /**
     * Updates the on-screen message based on the user's current
     * SMS permission and notification preference.
     */
    private void updatePermissionStatus() {

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        boolean notificationsEnabled =
                preferences.getBoolean(
                        "notifications_enabled",
                        false
                );

        if (permissionGranted && notificationsEnabled) {

            textPermissionStatus.setText(
                    "SMS notifications are enabled."
            );

        } else if (permissionGranted) {

            textPermissionStatus.setText(
                    "SMS permission is available, but notifications are currently disabled."
            );

        } else {

            textPermissionStatus.setText(
                    "SMS permission is not enabled."
            );
        }
    }
}