package com.example.myweightjourney_savannahpierce;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect Java variables to the views in activity_main.xml.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create access to the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Attempt to log in when the user taps the Log In button.
        buttonLogin.setOnClickListener(view -> loginUser());

        // Create a new account when the user taps the Create Account button.
        buttonCreateAccount.setOnClickListener(view -> createAccount());
    }

    /**
     * Checks the entered username and password against the users table.
     */
    private void loginUser() {

        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        // Make sure both fields contain information.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter both a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Verify the credentials stored in SQLite.
        if (databaseHelper.checkUser(username, password)) {

            Toast.makeText(
                    this,
                    "Login successful!",
                    Toast.LENGTH_SHORT
            ).show();

            openWeightTracker(username);

        } else {

            Toast.makeText(
                    this,
                    "Incorrect username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Creates a new account and stores the username and password
     * in the local SQLite database.
     */
    private void createAccount() {

        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        // Do not allow blank usernames or passwords.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Prevent duplicate usernames.
        if (databaseHelper.userExists(username)) {
            Toast.makeText(
                    this,
                    "That username already exists.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Add the new account to the database.
        boolean accountCreated = databaseHelper.addUser(username, password);

        if (accountCreated) {

            Toast.makeText(
                    this,
                    "Account created successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            openWeightTracker(username);

        } else {

            Toast.makeText(
                    this,
                    "Unable to create account.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Opens the weight tracker and passes along the logged-in username.
     */
    private void openWeightTracker(String username) {

        Intent intent = new Intent(
                MainActivity.this,
                WeightTrackerActivity.class
        );

        intent.putExtra("username", username);

        startActivity(intent);
    }
}