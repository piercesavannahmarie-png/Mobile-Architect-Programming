package com.example.myweightjourney_savannahpierce;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class WeightTrackerActivity extends AppCompatActivity {

    private EditText editEntryDate;
    private EditText editEntryWeight;
    private Button buttonAddWeight;
    private Button buttonOpenNotifications;
    private TableLayout tableWeightHistory;

    private DatabaseHelper databaseHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracker);

        // Connect Java variables to the views in the XML layout.
        editEntryDate = findViewById(R.id.editEntryDate);
        editEntryWeight = findViewById(R.id.editEntryWeight);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonOpenNotifications = findViewById(R.id.buttonOpenNotifications);
        tableWeightHistory = findViewById(R.id.tableWeightHistory);

        // Open the application's SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Receive the username passed from the login screen.
        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            Toast.makeText(
                    this,
                    "Unable to identify the logged-in user.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        // Add a new database entry when the user taps the button.
        buttonAddWeight.setOnClickListener(view -> addWeightEntry());

        // Open the SMS notification settings screen.
        buttonOpenNotifications.setOnClickListener(view -> {
            Intent intent = new Intent(
                    WeightTrackerActivity.this,
                    SmsNotificationsActivity.class
            );

            intent.putExtra("username", username);
            startActivity(intent);
        });

        // Display any weight entries already stored for this user.
        displayWeightEntries();
    }

    /**
     * Validates the entered date and weight and saves a new
     * weight record to the SQLite database.
     */
    private void addWeightEntry() {

        String date = editEntryDate.getText().toString().trim();
        String weightText = editEntryWeight.getText().toString().trim();

        if (date.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter both a date and weight.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {
            double weight = Double.parseDouble(weightText);

            if (weight <= 0) {
                Toast.makeText(
                        this,
                        "Please enter a valid weight.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            boolean added = databaseHelper.addWeight(
                    username,
                    date,
                    weight
            );

            if (added) {
                Toast.makeText(
                        this,
                        "Weight entry added!",
                        Toast.LENGTH_SHORT
                ).show();

                // Refresh the table to show the newly added record.
                displayWeightEntries();

                /*
                 * Check the new weight against the user's saved goal.
                 * SMS is only attempted when notifications are enabled
                 * and Android SMS permission has been granted.
                 */
                checkGoalAndSendSms(weight);

                // Clear the input boxes after successfully adding the record.
                editEntryDate.setText("");
                editEntryWeight.setText("");

            } else {
                Toast.makeText(
                        this,
                        "Unable to add weight entry.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException exception) {
            Toast.makeText(
                    this,
                    "Please enter a valid number for weight.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Checks whether the newly entered weight has reached the user's
     * goal. If SMS notifications are enabled and permission is granted,
     * the application sends a goal achievement message.
     */
    private void checkGoalAndSendSms(double currentWeight) {

        SharedPreferences preferences = getSharedPreferences(
                "sms_settings_" + username,
                MODE_PRIVATE
        );

        boolean notificationsEnabled = preferences.getBoolean(
                "notifications_enabled",
                false
        );

        String phoneNumber = preferences.getString(
                "phone_number",
                ""
        );

        String goalWeightText = preferences.getString(
                "goal_weight",
                ""
        );

        // SMS notifications are optional, so simply return if disabled.
        if (!notificationsEnabled) {
            return;
        }

        // Do not attempt SMS without saved notification information.
        if (phoneNumber.isEmpty() || goalWeightText.isEmpty()) {
            return;
        }

        try {
            double goalWeight = Double.parseDouble(goalWeightText);

            // The user's goal has not been reached yet.
            if (currentWeight > goalWeight) {
                return;
            }

            /*
             * Check permission again before attempting to send an SMS.
             * If permission was denied, the rest of the app continues
             * functioning normally.
             */
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED) {

                return;
            }

            sendGoalSms(phoneNumber, currentWeight, goalWeight);

        } catch (NumberFormatException exception) {
            // Invalid saved goal data should not interrupt weight tracking.
            Toast.makeText(
                    this,
                    "Unable to read the saved goal weight.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Sends an SMS message after the user reaches the saved goal weight.
     */
    private void sendGoalSms(
            String phoneNumber,
            double currentWeight,
            double goalWeight
    ) {

        String message =
                "Congratulations! You reached your MyWeightJourney goal. " +
                        "Your current weight is " +
                        String.format("%.1f", currentWeight) +
                        " lbs and your goal is " +
                        String.format("%.1f", goalWeight) +
                        " lbs.";

        try {
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal reached! SMS notification sent.",
                    Toast.LENGTH_LONG
            ).show();

        } catch (Exception exception) {

            /*
             * An emulator or device without SMS service may be unable
             * to physically send a text. The rest of the application
             * must continue to function if that happens.
             */
            Toast.makeText(
                    this,
                    "Goal reached, but the SMS could not be sent.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    /**
     * Reads the logged-in user's records from SQLite and dynamically
     * displays them underneath the header row of the weight table.
     */
    private void displayWeightEntries() {

        // Keep the XML header row but remove previously generated data rows.
        while (tableWeightHistory.getChildCount() > 1) {
            tableWeightHistory.removeViewAt(1);
        }

        Cursor cursor = databaseHelper.getWeights(username);

        if (cursor != null && cursor.moveToFirst()) {

            int idIndex = cursor.getColumnIndex("id");
            int dateIndex = cursor.getColumnIndex("date");
            int weightIndex = cursor.getColumnIndex("weight");

            do {
                int id = cursor.getInt(idIndex);
                String date = cursor.getString(dateIndex);
                double weight = cursor.getDouble(weightIndex);

                addWeightRow(id, date, weight);

            } while (cursor.moveToNext());

            cursor.close();
        }
    }

    /**
     * Creates one visible table row for a weight record.
     */
    private void addWeightRow(int id, String date, double weight) {

        TableRow row = new TableRow(this);
        row.setPadding(4, 4, 4, 4);

        TextView dateView = new TextView(this);
        dateView.setText(date);
        dateView.setPadding(8, 16, 8, 16);

        TextView weightView = new TextView(this);
        weightView.setText(String.format("%.1f lbs", weight));
        weightView.setGravity(Gravity.CENTER);
        weightView.setPadding(8, 16, 8, 16);

        // Place Edit and Delete controls together in the Action column.
        LinearLayout actionLayout = new LinearLayout(this);
        actionLayout.setOrientation(LinearLayout.HORIZONTAL);
        actionLayout.setGravity(Gravity.CENTER);

        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setAllCaps(false);

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setAllCaps(false);

        editButton.setOnClickListener(
                view -> showEditDialog(id, date, weight)
        );

        deleteButton.setOnClickListener(
                view -> confirmDelete(id)
        );

        actionLayout.addView(editButton);
        actionLayout.addView(deleteButton);

        row.addView(dateView);
        row.addView(weightView);
        row.addView(actionLayout);

        tableWeightHistory.addView(row);
    }

    /**
     * Displays a dialog that allows the user to update the selected
     * weight record's date and weight.
     */
    private void showEditDialog(
            int id,
            String currentDate,
            double currentWeight
    ) {

        LinearLayout dialogLayout = new LinearLayout(this);
        dialogLayout.setOrientation(LinearLayout.VERTICAL);

        int padding = (int) (
                20 * getResources().getDisplayMetrics().density
        );

        dialogLayout.setPadding(
                padding,
                padding,
                padding,
                padding
        );

        EditText dateInput = new EditText(this);
        dateInput.setHint("Date");
        dateInput.setText(currentDate);
        dateInput.setInputType(InputType.TYPE_CLASS_DATETIME);

        EditText weightInput = new EditText(this);
        weightInput.setHint("Weight");
        weightInput.setText(String.valueOf(currentWeight));
        weightInput.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL
        );

        dialogLayout.addView(dateInput);
        dialogLayout.addView(weightInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(dialogLayout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {

            Button saveButton = dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            );

            saveButton.setOnClickListener(view -> {

                String newDate =
                        dateInput.getText().toString().trim();

                String newWeightText =
                        weightInput.getText().toString().trim();

                if (newDate.isEmpty() || newWeightText.isEmpty()) {
                    Toast.makeText(
                            this,
                            "Please enter both a date and weight.",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                try {
                    double newWeight =
                            Double.parseDouble(newWeightText);

                    if (newWeight <= 0) {
                        Toast.makeText(
                                this,
                                "Please enter a valid weight.",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    boolean updated =
                            databaseHelper.updateWeight(
                                    id,
                                    newDate,
                                    newWeight
                            );

                    if (updated) {
                        Toast.makeText(
                                this,
                                "Weight entry updated!",
                                Toast.LENGTH_SHORT
                        ).show();

                        displayWeightEntries();
                        dialog.dismiss();

                    } else {
                        Toast.makeText(
                                this,
                                "Unable to update entry.",
                                Toast.LENGTH_SHORT
                        ).show();
                    }

                } catch (NumberFormatException exception) {
                    Toast.makeText(
                            this,
                            "Please enter a valid number for weight.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        });

        dialog.show();
    }

    /**
     * Confirms that the user wants to permanently delete a record.
     */
    private void confirmDelete(int id) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Entry")
                .setMessage(
                        "Are you sure you want to delete this entry?"
                )
                .setPositiveButton("Delete", (dialog, which) -> {

                    boolean deleted =
                            databaseHelper.deleteWeight(id);

                    if (deleted) {
                        Toast.makeText(
                                this,
                                "Weight entry deleted.",
                                Toast.LENGTH_SHORT
                        ).show();

                        displayWeightEntries();

                    } else {
                        Toast.makeText(
                                this,
                                "Unable to delete entry.",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}