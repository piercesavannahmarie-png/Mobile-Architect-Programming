package com.example.myweightjourney_savannahpierce;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyWeightJourney.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    // Weight entries table
    private static final String TABLE_WEIGHTS = "weights";
    private static final String WEIGHT_ID = "id";
    private static final String WEIGHT_USERNAME = "username";
    private static final String WEIGHT_DATE = "date";
    private static final String WEIGHT_VALUE = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Creates the table used to store login information.
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE NOT NULL, " +
                        PASSWORD + " TEXT NOT NULL)";

        // Creates the table used to store weight history.
        String createWeightsTable =
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        WEIGHT_USERNAME + " TEXT NOT NULL, " +
                        WEIGHT_DATE + " TEXT NOT NULL, " +
                        WEIGHT_VALUE + " REAL NOT NULL)";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        onCreate(db);
    }

    // Creates a new user account.
    public boolean addUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    // Checks whether a username already exists.
    public boolean userExists(String username) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + " = ?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // Checks the username and password during login.
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + " = ? AND " + PASSWORD + " = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean validUser = cursor.getCount() > 0;
        cursor.close();

        return validUser;
    }

    // Adds a new weight record for the logged-in user.
    public boolean addWeight(String username, String date, double weight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WEIGHT_USERNAME, username);
        values.put(WEIGHT_DATE, date);
        values.put(WEIGHT_VALUE, weight);

        long result = db.insert(TABLE_WEIGHTS, null, values);

        return result != -1;
    }

    // Returns all weight records belonging to one user.
    public Cursor getWeights(String username) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_WEIGHTS,
                null,
                WEIGHT_USERNAME + " = ?",
                new String[]{username},
                null,
                null,
                WEIGHT_ID + " DESC"
        );
    }

    // Updates an existing weight record.
    public boolean updateWeight(int id, String date, double weight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WEIGHT_DATE, date);
        values.put(WEIGHT_VALUE, weight);

        int rowsUpdated = db.update(
                TABLE_WEIGHTS,
                values,
                WEIGHT_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        return rowsUpdated > 0;
    }

    // Deletes an existing weight record.
    public boolean deleteWeight(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_WEIGHTS,
                WEIGHT_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        return rowsDeleted > 0;
    }
}